'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AtSign, Clock3, Moon, Share2, Sparkles, Sun, X } from 'lucide-react'

const TOPIC_GROUPS = {
  oratoria: {
    label: 'Oratoria',
    icon: '◌',
    topics: ['La primera impresión', 'El poder de escuchar', 'Cómo contar una historia', 'El miedo a equivocarse', 'La pausa como herramienta', 'Hablar con claridad', 'El lenguaje corporal', 'Convencer sin imponer', 'Liderar una conversación'],
  },
  economia: {
    label: 'Economía',
    icon: '◈',
    topics: ['La inflación', 'El valor del tiempo', 'Ahorrar o invertir', 'El precio de las decisiones', 'Oferta y demanda', 'El futuro del trabajo', 'Dinero y felicidad'],
  },
  cultura: {
    label: 'Cultura',
    icon: '▣',
    topics: ['Una obra que cambió el mundo', 'El poder de la música', 'Tradición y cambio', 'La curiosidad', 'Una ciudad que inspira', 'El papel de los libros', 'La belleza de lo cotidiano'],
  },
  aleatorio: {
    label: 'De todo',
    icon: '✦',
    topics: ['Una idea que cambió tu vida', 'Tu mayor aprendizaje', 'La tecnología del futuro', '¿Qué significa vivir bien?', 'Una decisión difícil', 'El miedo y el coraje', 'La importancia del humor'],
  },
} as const

type TopicGroup = keyof typeof TOPIC_GROUPS
const TOPICS = Object.values(TOPIC_GROUPS).flatMap((group) => group.topics)

function metallicTick() {
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
  if (!AudioContextClass) return
  const context = new AudioContextClass()
  const oscillator = context.createOscillator()
  const gain = context.createGain()
  oscillator.type = 'square'
  oscillator.frequency.setValueAtTime(1500, context.currentTime)
  oscillator.frequency.exponentialRampToValueAtTime(420, context.currentTime + 0.055)
  gain.gain.setValueAtTime(0.045, context.currentTime)
  gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.06)
  oscillator.connect(gain).connect(context.destination)
  oscillator.start()
  oscillator.stop(context.currentTime + 0.06)
  window.setTimeout(() => void context.close(), 100)
}

export function ImpromptuApp() {
  const [category, setCategory] = useState<TopicGroup>('oratoria')
  const [categoryOpen, setCategoryOpen] = useState(false)
  const [topic, setTopic] = useState(TOPIC_GROUPS.oratoria.topics[1])
  const [spinning, setSpinning] = useState(false)
  const categoryTopics = TOPIC_GROUPS[category].topics
  const [mode, setMode] = useState<'improvisado' | 'profundo'>('improvisado')
  const [light, setLight] = useState(false)
  const [timerOpen, setTimerOpen] = useState(false)
  const [shareOpen, setShareOpen] = useState(false)
  const [seconds, setSeconds] = useState(60)
  const timerRef = useRef<number | null>(null)
  const topicIndex = useMemo(() => categoryTopics.indexOf(topic) + 1, [categoryTopics, topic])

  useEffect(() => {
    setLight(window.localStorage.getItem('impromptu-theme') === 'light')
  }, [])

  useEffect(() => {
    if (!timerOpen || seconds <= 0) return
    timerRef.current = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000)
    return () => { if (timerRef.current) window.clearInterval(timerRef.current) }
  }, [timerOpen, seconds])

  function toggleTheme() {
    const next = !light
    setLight(next)
    window.localStorage.setItem('impromptu-theme', next ? 'light' : 'dark')
  }

  async function shareApp() {
    const shareData = { title: 'Impromptu', text: `Practica tu oratoria: ${topic}`, url: window.location.href }
    if (navigator.share) {
      await navigator.share(shareData).catch(() => undefined)
    } else {
      setShareOpen((value) => !value)
    }
  }

  function spin() {
    if (spinning) return
    setSpinning(true)
    const finalIndex = Math.floor(Math.random() * categoryTopics.length)
    const steps = 25 + ((finalIndex - categoryTopics.indexOf(topic) + categoryTopics.length) % categoryTopics.length)
    let step = 0
    const tick = () => {
      const current = (categoryTopics.indexOf(topic) + step + 1) % categoryTopics.length
      setTopic(categoryTopics[current])
      metallicTick()
      step += 1
      if (step < steps) window.setTimeout(tick, 55 + step * 7)
      else setSpinning(false)
    }
    tick()
  }

  const formatted = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`
  const progress = (seconds / 60) * 360

  return (
    <main className={`impromptu-shell ${light ? 'light-theme' : ''}`}>
      <header className="topbar">
        <div className="brand-block"><h1>IMPROMPTU</h1><p>made by <span><AtSign aria-hidden="true" /> J.C/Yassper</span></p></div>
        <div className="utility-nav" aria-label="Herramientas">
          <button aria-label={light ? 'Activar modo oscuro' : 'Activar modo claro'} onClick={toggleTheme} type="button">{light ? <Sun /> : <Moon />}</button>
          <div className="share-wrap">
            <button aria-expanded={shareOpen} aria-label="Compartir" onClick={shareApp} type="button"><Share2 /></button>
            {shareOpen && <div className="share-menu" role="menu"><button type="button" onClick={() => { window.open(`https://wa.me/?text=${encodeURIComponent(`Practica tu oratoria con Impromptu: ${window.location.href}`)}`, '_blank'); setShareOpen(false) }}>WhatsApp</button><button type="button" onClick={() => { window.open(`mailto:?subject=Impromptu&body=${encodeURIComponent(window.location.href)}`, '_blank'); setShareOpen(false) }}>Email</button><button type="button" onClick={() => { void navigator.clipboard?.writeText(window.location.href); setShareOpen(false) }}>Copiar enlace</button></div>}
          </div>
        </div>
      </header>

      <section className="practice-area" aria-labelledby="practice-title">
        <div className="mode-toggle" role="group" aria-label="Modo de práctica">
          <button className={mode === 'improvisado' ? 'active' : ''} onClick={() => setMode('improvisado')} type="button">Improvisado</button>
          <button className={mode === 'profundo' ? 'active' : ''} onClick={() => setMode('profundo')} type="button">Investigación profunda</button>
        </div>
        <p className="intro" id="practice-title">{mode === 'improvisado' ? 'Elige un universo y deja que el azar te dé la palabra.' : 'Tómate 15 minutos para aprender y luego explícalo en 1 minuto.'}</p>
        {mode === 'improvisado' && <div className="category-picker" aria-label="Categoría de temas">
          <label className="category-label" htmlFor="topic-category">Temas</label>
          <div className="category-select-wrap">
            <button id="topic-category" className="category-select-trigger" type="button" disabled={spinning} aria-haspopup="listbox" aria-expanded={categoryOpen} aria-label="Seleccionar categoría de temas" onClick={() => setCategoryOpen((value) => !value)}>
              <span className="category-select-icon" aria-hidden="true">{TOPIC_GROUPS[category].icon}</span>
              <span>{TOPIC_GROUPS[category].label}</span>
              <span className="category-chevron" aria-hidden="true">⌄</span>
            </button>
            {categoryOpen && <div className="category-menu" role="listbox" aria-label="Categorías disponibles">
              {(Object.entries(TOPIC_GROUPS) as [TopicGroup, (typeof TOPIC_GROUPS)[TopicGroup]][]).map(([key, group]) => <button key={key} className={category === key ? 'category-option selected' : 'category-option'} type="button" role="option" aria-selected={category === key} onClick={() => { setCategory(key); setTopic(group.topics[0]); setCategoryOpen(false) }}><span aria-hidden="true">{group.icon}</span><span>{group.label}</span>{category === key && <span className="category-check" aria-hidden="true">✓</span>}</button>)}
            </div>}
          </div>
        </div>}
        <div className={`deck-stage ${spinning ? 'is-running' : ''}`} aria-live="polite">
          <div className="ghost-card ghost-top"><span>{categoryTopics[(topicIndex + 1) % categoryTopics.length]}</span></div>
          <div className="ghost-card ghost-bottom"><span>{categoryTopics[(topicIndex + 2) % categoryTopics.length]}</span></div>
          <div className="side-arrow" aria-hidden="true">›</div>
          <article className="topic-card"><div className="card-meta"><span>{mode === 'improvisado' ? TOPIC_GROUPS[category].label.toUpperCase() : 'INVESTIGACIÓN PROFUNDA'}</span><span>{topicIndex} / {TOPICS.length}</span></div><h2>{topic}</h2><div className="card-footer"><span>IMPROMPTU</span><span>··</span></div></article>
          <aside className="annotation"><strong>PIENSA EN 30s</strong><br /><span className="annotation-line">DILO EN 1m</span> <span aria-hidden="true">↙</span></aside>
        </div>
        <div className="actions"><button className="spin-button" disabled={spinning} onClick={spin} type="button"><Sparkles aria-hidden="true" /> {spinning ? 'Bajando…' : topicIndex === 2 ? 'Girar el mazo' : 'Girar de nuevo'}</button><button className="timer-button" onClick={() => { setSeconds(60); setTimerOpen(true) }} type="button"><Clock3 aria-hidden="true" /> Timer 1 min</button></div>
      </section>

      {timerOpen && <div className="timer-overlay" role="dialog" aria-modal="true" aria-label="Temporizador de oratoria"><button className="close-timer" aria-label="Cerrar temporizador" onClick={() => setTimerOpen(false)} type="button"><X /></button><div className="timer-label">{mode === 'profundo' ? 'INVESTIGACIÓN PROFUNDA' : 'ORATORIA'}</div><h2>{topic}</h2><div className="timer-dial" style={{ '--progress': `${progress}deg` } as React.CSSProperties}><div className="timer-dial-inner"><strong>{formatted}</strong></div></div><p>{seconds === 0 ? 'Tiempo.' : 'Hablá.'}</p><button className="timer-close-link" onClick={() => setTimerOpen(false)} type="button">Cerrar</button></div>}
      <footer><span>© 2026 Impromptu. Todos los derechos reservados.</span><span className="idea-credit">Idea de Francisco Annoni</span></footer>
    </main>
  )
}

export { TOPICS }
